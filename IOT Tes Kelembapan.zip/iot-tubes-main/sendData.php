<?php
$connect = mysqli_connect("localhost:3307", "root", "", "data_sensor");

$sensor = $_GET["sensor"];
$minValue = 0; // Replace with the minimum value of the sensor range
$maxValue = 1023; // Replace with the maximum value of the sensor range

// Convert sensor value to percentage
$percentage = ($sensor - $minValue) / ($maxValue - $minValue) * 100;

date_default_timezone_set('Asia/Jakarta');
$currentDateTime = date("Y-m-d H:i:s");
$query = "INSERT INTO kelembaban (value, date) values ($percentage, '$currentDateTime')";
echo ($query);

mysqli_query($connect, $query);

 