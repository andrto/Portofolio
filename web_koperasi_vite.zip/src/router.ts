import { createRouter, createWebHistory } from "vue-router";
import Home from "./pages/Home.vue";
import TentangKami from "./pages/TentangKami.vue";
// import NavigasiBar from "./components/NavigasiBar.vue";
import Kontak from "./pages/Kontak.vue";
import Login from "./pages/Login.vue";
import Registrasi from "./pages/Registrasi.vue";
import Artikel from "./pages/Artikel.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", component: Home },
    { path: "/tentangKami", component: TentangKami },
    { path: "/kontak", component: Kontak },
    { path: "/Artikel", component: Artikel },
    { path: "/login", component: Login },
    { path: "/registrasi", component: Registrasi },
  ],
});

export default router;
