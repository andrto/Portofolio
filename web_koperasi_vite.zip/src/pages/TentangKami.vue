<script setup lang="ts">
import NavigasiBar from "../components/NavigasiBar.vue";
</script>

<template>
  <div class="bg-gradient-to-t from-[#0D70B8] to-[#238CCB] h-screen">
    <!-- NAVBAR -->
    <NavigasiBar />

    <main>
      <div class="flex items-center justify-around p-20 mt-3">
        <div class="text-white">
          <!-- Deksripsi -->
          <div>
            <div class="font-[700] text-[40px] leading-4">
              Deus Credit Union
            </div>
            <div class="font-[500] text-[30px] mt-3">Prosperity For All</div>
            <div class="font-[500] text-[18px] mt-8">
              Deus Credit Union adalah aplikasi koperasi digital yang dirancang
              <br />
              oleh PT. Deus Code Studio untuk membantu Anda mengelola <br />
              keuangan karyawan dengan mudah dan nyaman. Mulai dari <br />
              memberikan penyuluhan kebiasaan menabung, bpjs dan dana <br />
              pensiun.
            </div>
          </div>
          <!-- VISI -->
          <div>
            <div class="font-[700] text-[40px] mt-4">VISI</div>
            <div class="font-[500] text-[18px]">
              Berkomitmen untuk meningkatkan kesejahteraan 1.000 karyawan di
              <br />
              Indonesia
            </div>
          </div>
          <!-- MISI -->
          <div>
            <div class="font-[700] text-[40px] mt-4">MISI</div>
            <div class="font-[500] text-[18px]">
              <ol>
                <li class="flex gap-3">
                  <div>1.</div>
                  Memberikan kebiasaan kepada karyawan untuk rutin menabung.
                </li>
                <li class="flex gap-2">
                  <div>2.</div>
                  Memberikan pelatihan keuangan dan strategi pengelolaan
                  anggaran <br />
                  untuk membantu karyawan meningkatkan tabungan mereka Agar
                  <br />
                  karyawan dapat mempersiapkan dan menikmati masa pensiun <br />
                  kelak.
                </li>
                <li class="flex gap-2">
                  <div>3.</div>
                  Memberikan peluang untuk mendapatkan keuntungan (SHU) dan
                  <br />
                  penghasilan tambahan melalui marketplace.
                </li>
              </ol>
            </div>
          </div>
        </div>
        <!-- Image -->
        <div>
          <img
            src="../assets/AboutAssets/imageDCU.svg"
            width="550"
            alt="gambar dcu"
          />
        </div>
      </div>
    </main>
  </div>
</template>
