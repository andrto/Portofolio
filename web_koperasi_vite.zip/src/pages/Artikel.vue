<script setup lang="ts">
import Navigasi from "../components/NavigasiBar.vue";
</script>

<template>
  <div>
    <nav>
      <Navigasi />
    </nav>

    <main>
      <div class="p-16 px-32">
        <!-- Artikel Unggulan -->
        <div>
          <!-- Header -->
          <div class="border-l-[#124C88] border-l-4 px-5 py-1">
            <div
              class="text-[18px] font-[700] text-[#124C8880] text-opacity-50"
            >
              Artikel
            </div>
            <div class="text-[30px] font-[700] text-[#124C88]">UNGGULAN</div>
          </div>
          <!-- Artikel 1 -->
          <div class="my-16">
            <div class="flex gap-8 items-start">
              <div>
                <img
                  src="../assets/ArtikelAssets/imgUnggulan1.svg"
                  alt="gambar artikel"
                />
              </div>
              <div>
                <div
                  class="text-[24px] text-[#124C88] font-[700] mt-1 leading-3"
                >
                  Keunggulan Koperasi Digital DCU Dibandingkan Dengan Pinjaman
                  Online atau Pinjol
                </div>
                <div
                  class="text-[18px] font-[500] text-[#545454] text-justify w-[70%] my-5"
                >
                  Deus Credit Union adalah aplikasi koperasi digital yang
                  dirancang oleh PT. Deus Code Studio untuk membantu Anda
                  mengelola keuangan karyawan dengan mudah dan nyaman. Mulai
                  dari memberikan penyuluhan kebiasaan menabung, bpjs dan dana
                  pensiun.
                </div>
                <button
                  class="bg-[#1F87C7] text-white text-[12px] font-[500] py-1.5 px-3 rounded-md"
                >
                  Baca Selengkapnya
                </button>
              </div>
            </div>
            <!-- Artikel 2 -->
            <div class="flex gap-8 items-start my-16">
              <div>
                <img
                  src="../assets/ArtikelAssets/imgUnggulan2.svg"
                  alt="gambar artikel"
                />
              </div>
              <div>
                <div
                  class="text-[24px] text-[#124C88] font-[700] mt-1 leading-3"
                >
                  Apasi Manfaat Koperasi Digital ?
                </div>
                <div
                  class="text-[18px] font-[500] text-[#545454] text-justify w-[70%] my-5"
                >
                  Deus Credit Union adalah aplikasi koperasi digital yang
                  dirancang oleh PT. Deus Code Studio untuk membantu Anda
                  mengelola keuangan karyawan dengan mudah dan nyaman. Mulai
                  dari memberikan penyuluhan kebiasaan menabung, bpjs dan dana
                  pensiun.
                </div>
                <button
                  class="bg-[#1F87C7] text-white text-[12px] font-[500] py-1.5 px-3 rounded-md"
                >
                  Baca Selengkapnya
                </button>
              </div>
            </div>
            <!-- Artikel 3 -->
            <div class="flex gap-8 items-start">
              <div>
                <img
                  src="../assets/ArtikelAssets/imgUnggulan3.svg"
                  alt="gambar artikel"
                />
              </div>
              <div>
                <div
                  class="text-[24px] text-[#124C88] font-[700] mt-1 leading-3"
                >
                  Keunggulan Koperasi Digital DCU Dibandingkan Dengan Pinjaman
                  Online atau Pinjol
                </div>
                <div
                  class="text-[18px] font-[500] text-[#545454] text-justify w-[70%] my-5"
                >
                  Deus Credit Union adalah aplikasi koperasi digital yang
                  dirancang oleh PT. Deus Code Studio untuk membantu Anda
                  mengelola keuangan karyawan dengan mudah dan nyaman. Mulai
                  dari memberikan penyuluhan kebiasaan menabung, bpjs dan dana
                  pensiun.
                </div>
                <button
                  class="bg-[#1F87C7] text-white text-[12px] font-[500] py-1.5 px-3 rounded-md"
                >
                  Baca Selengkapnya
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Berita Lainnya -->
        <div>
          <!-- header -->
          <div>
            <div class="text-[30px] font-[700] text-[#124C88]">
              BERITA LAINNYA
            </div>
            <div class="text-[15px] font-[500] text-[#124C88]">
              <a href="">Selengkapnya >>></a>
            </div>
          </div>
          <!-- Section Card Berita -->
          <div>
            <div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>
