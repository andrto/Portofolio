<script lang="ts">
// inisialisasi fungsi click ke false
import { defineComponent, ref } from "vue";
import { RouterLink } from "vue-router";

export default defineComponent({
  setup() {
    const isInputClicked = ref(false);
    const isInputClicked2 = ref(false);
    return { isInputClicked, isInputClicked2 };
  },
});
</script>

<template>
  <div
    class="bg-gradient-to-t from-[#228BCA] to-[#0F72B9] h-screen flex items-center justify-center"
  >
    <div class="bg-white p-8 pt-7.5 pb-6 w-[30%] rounded-xl">
      <!-- Logo -->
      <div class="flex justify-center items-center">
        <img src="../assets/LogoDcu.svg" alt="Logo Dcu" />
      </div>
      <!-- Desk -->
      <div class="text-center my-4 text-[#124C88]">
        <div class="text-[18px] font-[700]">MEMBER</div>
        <div class="text-[16px] font-[500]">
          Koperasi Konsumen Deus Credit Union
        </div>
      </div>
      <!-- Form -->
      <div>
        <!-- Nomor -->
        <div class="w-full">
          <div class="text-[#124C88] font-[600]">Nomor Hp Aktif</div>
          <input
            type="text"
            placeholder="+62 ********"
            @click="isInputClicked = true"
            :required="isInputClicked"
            class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454] invalid:placeholder-red-500"
          />
        </div>
        <!-- Password -->
        <div class="my-5">
          <div class="text-[#124C88] font-[600]">Password</div>
          <input
            type="password"
            placeholder="Terdiri 8 karakter "
            @click="isInputClicked2 = true"
            :required="isInputClicked2"
            class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454] invalid:placeholder-red-500"
          />
        </div>
        <!-- Kode referal -->
        <div>
          <div class="text-[#124C88] font-[600]">Kode Referral</div>
          <input
            type="text"
            placeholder="Gunakan kode referral sebelumnya"
            class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
          />
        </div>
      </div>
      <!-- Ingat Saya / Lupa Password -->
      <div class="flex justify-between my-4">
        <div class="flex items-center">
          <input
            type="checkbox"
            class="appearance-none h-4 w-4 bg-[#D9D9D9] border-0 checked:appearance-auto checked:accent-[#228BCA] rounded-sm mr-3"
          />
          <div class="text-[#124C88] font-[500] text-14px">Ingat Saya</div>
        </div>
        <div>
          <RouterLink to="#" class="text-[#545454] font-[500] text-[14.5px]"
            >Lupa Password ?</RouterLink
          >
        </div>
      </div>
      <!-- Tombol Masuk -->
      <div class="text-center">
        <button
          type="submit"
          class="bg-[#124C88] w-full text-white py-2 rounded-lg text-[16px] font-[600]"
        >
          <RouterLink to="/">MASUK</RouterLink>
        </button>
      </div>
      <!-- Register -->
      <div class="flex justify-center items-center mt-5">
        <div class="text-[#545454] text-[14px] font-[600]">
          Belum punya akun ?
          <RouterLink to="/Registrasi" class="text-[#124C88]"
            >Register</RouterLink
          >
        </div>
      </div>
    </div>
  </div>
</template>

<style></style>
