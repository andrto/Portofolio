<script setup lang="ts">
import NavigasiBar from "../components/NavigasiBar.vue";
</script>

<template>
  <div class="bg-gradient-to-t from-[#0D70B8] to-[#238CCB] h-screen">
    <!-- NAVBAR -->
    <NavigasiBar />

    <!-- MAIN -->
    <main class="p-20 px-15">
      <div class="flex justify-between m-20 items-center">
        <div class="text-white">
          <!-- Deskripsi -->
          <div class="text-[48px] font-[700]">
            Deus Siap <br />
            Mensejahterakan <br />Karyawan
          </div>
          <div class="font-[500] text-[17px] my-8">
            Deus merupakan aplikasi koperasi terverifikasi & aman <br />
            berkomitmen mensejahterakan karyawan serta memberikan <br />
            peluang untuk mendapatkan keuntungan di masa depan.
          </div>

          <!-- Button -->
          <div>
            <button
              class="flex items-center gap-2 bg-[#114780] p-3 pt-2.5 px-4 rounded-md"
            >
              Daftar Sekarang!
              <img
                src="../assets/HomeAssets/logoArrowR.svg"
                width="15"
                class="pt-0.5"
                alt=""
              />
            </button>
          </div>
          <!-- Video -->
          <div class="flex items-center mt-7 gap-7 text-[12px]">
            <button>
              <img src="../assets/HomeAssets/logoPlayVideo.svg" alt="" />
            </button>
            <div class="">Video berita tentang kami</div>
          </div>
        </div>
        <div>
          <img src="../assets/HomeAssets/imagePeople.svg" alt="" />
        </div>
      </div>
    </main>
  </div>
</template>
