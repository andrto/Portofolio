<script setup lang="ts">
import Navigasi from "../components/NavigasiBar.vue";
</script>

<template>
  <div class="bg-gradient-to-t from-[#0D70B8] to-[#238CCB] h-screen">
    <!-- Navigasi Bar -->
    <Navigasi />
    <div class="flex items-center justify-center gap-10 m-10">
      <!-- Sisi Kontak Kami -->
      <div class="bg-[#E8EFF7] py-2 px-7 pr-24 rounded-2xl">
        <!-- Deskripsi -->
        <div>
          <div class="text-[45px] font-[600] leading-3 mt-8">Kontak Kami</div>
          <div class="my-10 mb-8">
            Hubungi kami jika terjadinya kesalahan mengenai koperasi simpan
            <br />
            pinjam kami, jika ada yang ingin di sampaikan silahkan hubungi kami
            <br />
            pesan anda akan sangat membantu kami terkait apapun
          </div>
        </div>
        <!-- Form kontak kami -->
        <div>
          <div>
            <!-- Logo -->
            <div class="flex gap-4 items-center text-[#175FAA] font-normal">
              <img
                src="../assets/KontakAssets/logoLocation.svg"
                alt="logo location"
              />
              Offline
            </div>
            <!-- Input -->
            <div
              class="font-[350] w-[65%] pl-8 py-2 border-b-[#175FAA] border-b"
            >
              Jl. Cigar Smoke CS. DKI JAKARTA 13256. <br />
              Indonesia
            </div>
          </div>
          <div class="my-10">
            <!-- Logo -->
            <div class="flex gap-3 items-center text-[#175FAA] font-normal">
              <img
                src="../assets/KontakAssets/LogoEmail.svg"
                alt="logo email"
              />
              Email
            </div>
            <!-- Input -->
            <div
              class="font-[350] w-[65%] pl-8 py-2 border-b-[#175FAA] border-b"
            >
              deuscreditunion@gmail.com
            </div>
          </div>
          <div>
            <!-- Logo -->
            <div class="flex gap-3 items-center text-[#175FAA] font-normal">
              <img
                src="../assets/KontakAssets/logoTelepon.svg"
                alt="logo telepon"
              />
              Telepon
            </div>
            <!-- Input -->
            <div
              class="font-[350] w-[65%] pl-8 py-2 border-b-[#175FAA] border-b"
            >
              +62 123 4567 891
            </div>
          </div>
        </div>
        <!-- Link kontak -->
        <div class="my-10">
          <div>Follow me</div>
          <div>
            <!-- instagram -->
            <div class="flex gap-3.5 items-center underline font-[400] mt-3">
              <div>
                <img
                  src="../assets/KontakAssets/logoInstagram.svg"
                  alt="logo instagram"
                />
              </div>
              <div>
                <a href="https://www.instagram.com/deuscreditunion/"
                  >Deus Credit Union (@deuscreditunion)</a
                >
              </div>
            </div>
            <!-- Youtube -->
            <div class="flex gap-3 items-center underline font-[400] mt-3">
              <div>
                <img
                  src="../assets/KontakAssets/logoYoutube.svg"
                  alt="logo youtube"
                />
              </div>
              <div>
                <a
                  href="https://www.youtube.com/channel/UCz119SSCaNm15CHExX_FN0w"
                  >Deus Credit Union - YouTube</a
                >
              </div>
            </div>
            <!-- Blogspot -->
            <div class="flex gap-3 items-center underline font-[400] mt-3">
              <div>
                <img
                  src="../assets/KontakAssets/logoBlogspot.svg"
                  alt="logo blogspot"
                />
              </div>
              <div>
                <a href="https://kelompok12internship.blogspot.com/"
                  >Deus Credit Union</a
                >
              </div>
            </div>
            <!-- Facebook -->
            <div class="flex gap-5 items-center underline font-[400] mt-3">
              <div>
                <img
                  src="../assets/KontakAssets/logoFb.svg"
                  alt="logo facebook"
                />
              </div>
              <div>
                <a
                  href="https://www.facebook.com/people/Dcu-Koperasi/61559606948162/"
                  >https://www.facebook.com/</a
                >
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Sisi Kirim Pesan -->
      <div
        class="flex bg-[#E8EFF7] items-center justify-center w-[30%] rounded-2xl py-9"
      >
        <div class="w-full px-5">
          <!-- Desk -->
          <div class="flex items-center justify-center font-[600] text-[40px]">
            Kirim Pesan
          </div>
          <!-- Form -->
          <div class="mt-16">
            <!-- Email & Telepone -->
            <div class="flex gap-[60px] my-5 mb-8">
              <div class="grow">
                <div class="font-[600] text-[16px]">Email</div>
                <input
                  type="text"
                  placeholder="Email..."
                  class="p-3 py-2 rounded-lg font-[600] text-[12px] w-full outline-none text-[#545454]"
                />
              </div>
              <div class="grow">
                <div class="font-[600] text-[16px]">No. Telepon</div>
                <input
                  type="text"
                  placeholder="Telepon..."
                  class="p-3 py-2 rounded-lg font-[600] text-[12px] w-full outline-none text-[#545454]"
                />
              </div>
            </div>
            <!-- Nama -->
            <div class="mb-8">
              <div class="font-[600] text-[16px]">Nama</div>
              <input
                type="text"
                placeholder="Nama..."
                class="w-full p-3 py-2 rounded-lg font-[600] text-[12px] outline-none text-[#545454]"
              />
            </div>
            <!-- Pesan -->
            <div>
              <div class="font-[600] text-[16px]">Pesan</div>
              <textarea
                type="text"
                placeholder="Pesan..."
                class="w-full p-3 py-2 rounded-lg font-[600] text-[12px] resize-none h-48 outline-none text-[#545454]"
              ></textarea>
            </div>
          </div>
          <!-- Submit -->
          <div class="flex items-center justify-end my-12">
            <button class="bg-[#124C88] p-3 rounded-lg">
              <img src="../assets/KontakAssets/logoKirim.svg" alt="" />
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
