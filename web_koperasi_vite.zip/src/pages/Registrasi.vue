<script lang="ts">
import { RouterLink } from 'vue-router';

export default {
  data() {
    return {
      showModalDaftar: false,
      showModalSukses: false,
    };
  },
};
</script>

<template>
  <div
    class="bg-gradient-to-t from-[#228BCA] to-[#0F72B9] h-screen flex items-center justify-center"
  >
    <!-- Form -->
    <div class="bg-white p-8 pt-7.5 pb-6 w-[30%] rounded-xl">
      <div>
        <!-- Logo -->
        <div class="flex justify-center items-center">
          <img src="../assets/LogoDcu.svg" alt="Logo Dcu" />
        </div>
        <!-- Desk -->
        <div class="text-center my-4 text-[#124C88]">
          <div class="text-[18px] font-[700]">DAFTAR MEMBER</div>
          <div class="text-[16px] font-[500]">
            Koperasi Konsumen Deus Credit Union
          </div>
        </div>
        <!-- Form -->
        <div>
          <!-- Nama Lengkap -->
          <div>
            <div class="text-[#124C88] font-[600]">Nama Lengkap</div>
            <input
              type="text"
              placeholder="Isi sesuai KTP"
              class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
            />
          </div>
          <!-- NIK -->
          <div class="my-5">
            <div class="text-[#124C88] font-[600]">
              Nomor Kependudukan Nasional (NIK)
            </div>
            <input
              type="text"
              placeholder="Terdiri dari 16 digit angka"
              class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
            />
          </div>
          <!-- Nomor WA -->
          <div>
            <div class="text-[#124C88] font-[600]">
              Nomer HP Aktif (Terhubung dengan whatsapp)
            </div>
            <input
              type="text"
              placeholder="+62 ********"
              class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
            />
          </div>
          <!-- Kode Referal -->
          <div class="my-5">
            <div class="text-[#124C88] font-[600]">Kode Referral</div>
            <input
              type="text"
              placeholder="Opsional"
              class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
            />
          </div>
          <!-- Password -->
          <div>
            <div class="text-[#124C88] font-[600]">Password</div>
            <input
              type="text"
              placeholder="Password minimal 8 karakter bebas"
              class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
            />
          </div>
          <!-- Konfimasi Password -->
          <div class="my-5">
            <div class="text-[#124C88] font-[600]">Konfimasi Password</div>
            <input
              type="text"
              placeholder="Ulangi password"
              class="w-full border-b-[#124C88] border-b-2 py-2 outline-none text-[#545454]"
            />
          </div>
        </div>
        <!-- Checkboxes -->
        <div>
          <div class="flex items-center">
            <input
              type="checkbox"
              class="appearance-none border-0 outline-none ring-0 h-4 bg-[#D9D9D9] checked:appearance-auto checked:accent-[#228BCA] checked:rounded-sm rounded-sm pr-4 mr-4"
            />
            <div class="text-[#124C88] font-[500] text-[13.5px]">
              Dengan mendaftar/login sebagai member, anda berarti menyetujui
              syarat <br />
              dan ketentuan yang berlaku pada koperasi dan aplikasi ini.
            </div>
          </div>
        </div>
        <!-- Tombol Regis -->
        <div class="text-center mt-8 mb-3">
          <button
            type="submit"
            @click="showModalDaftar = true"
            class="bg-[#124C88] w-full text-white py-2 rounded-lg text-[16px] font-[600]"
          >
            DAFTAR
          </button>
        </div>
      </div>
      <!-- MODAL -->
      <!-- Modal Daftar -->
      <div
        v-if="showModalDaftar"
        class="fixed inset-0 flex items-center justify-center bg-[rgb(128,128,128,0.37)]"
      >
        <div @click="showModalDaftar = false" class="fixed inset-0 z-5"></div>

        <div class="bg-white text-center p-8 px-16 rounded-2xl w-[23%] z-10">
          <div class="font-[700] text-[18px] text-[#175FAA]">
            Daftarkan PIN DCU
          </div>
          <div class="font-[500] text-[15px] mt-2">
            PIN akan digunakan untuk keamanan<br />
            akun anda di aplikasi DCU
          </div>
          <input
            type="password"
            placeholder="6 digit angka"
            class="w-full text-center outline-none border-[#155699] border-2 rounded-xl py-1.5 my-5 mt-4 text-[#3C3C3C4D] text-opacity-[30%]"
          />
          <button
            @click="
              showModalDaftar = false;
              showModalSukses = true;
            "
            class="bg-[#175FAA] text-white w-full rounded-lg py-1"
          >
            Masukan PIN
          </button>
        </div>
      </div>
      <!-- Modal Sukses -->
      <div
        v-if="showModalSukses"
        class="fixed inset-0 flex items-center justify-center bg-[rgb(128,128,128,0.37)]"
      >
        <div class="bg-white text-center p-8 px-14 rounded-2xl w-[20%] z-10">
          <div class="font-[700] text-[18px] text-[#175FAA]">
            Berhasil Membuat Akun
          </div>
          <div class="font-500 text-[14px] mt-2 mb-8">
            Silahkan masuk kembali
          </div>
          <button class="bg-[#175FAA] text-white w-full rounded-lg py-1">
            <RouterLink to="/Login">MASUK</RouterLink>
          </button
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
