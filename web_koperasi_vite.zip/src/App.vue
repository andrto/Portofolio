<script setup lang="ts"></script>

<template>
  <Home />
  <router-view />
</template>
