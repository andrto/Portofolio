<script setup lang="ts">
import { RouterLink } from "vue-router";
</script>

<template>
  <nav>
    <div
      class="bg-white flex items-center p-7 pt-6 justify-between shadow-[0_10px_50px_-15px_rgba(0,0,0,0.3)]"
    >
      <div>
        <img
          src="../assets/logoDcuNew.svg"
          width="250"
          alt="logo dcu"
          class="absolute top-2 left-20"
        />
      </div>
      <div class="flex items-center gap-8 mr-10">
        <div class="text-[#939393] text-[18px] font-[700] hover:text-[#175FAA]">
          <RouterLink to="/" class="active:text-[#175FAA]"> Home </RouterLink>
        </div>
        <div class="text-[#939393] text-[18px] font-[700] hover:text-[#175FAA]">
          <RouterLink to="/tentangKami"> Tentang Kami </RouterLink>
        </div>
        <div class="text-[#939393] text-[18px] font-[700] hover:text-[#175FAA]">
          <RouterLink to="#"> Fitur </RouterLink>
        </div>
        <div class="text-[#939393] text-[18px] font-[700] hover:text-[#175FAA]">
          <RouterLink to="/Artikel"> Artikel </RouterLink>
        </div>
        <div class="text-[#939393] text-[18px] font-[700] hover:text-[#175FAA]">
          <RouterLink to="/Kontak"> Kontak </RouterLink>
        </div>
        <div class="flex items-center">
          <RouterLink
            to="/Login"
            class="flex bg-[#175FAA] text-white p-2 px-6 items-center gap-2 rounded-md"
          >
            Register/Login
            <img
              src="../assets/HomeAssets/logoArrowR.svg"
              width="13"
              class="mt-0.5"
              alt=""
            />
          </RouterLink>
        </div>
      </div>
    </div>
  </nav>
</template>
